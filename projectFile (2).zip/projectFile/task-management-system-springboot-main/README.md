# To do list Management using spring boot

Functionalities 
	<li>add new task info</li>
	<li>update task info</li>
	<li>delete task info </li>
	<li>search task by title or by due date</li>
	<li>mark task as completed </li>


import the project and you can run it eit as a project as a whole or individual functions of each class 

