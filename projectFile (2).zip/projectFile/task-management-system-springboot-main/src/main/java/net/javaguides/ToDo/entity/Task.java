package net.javaguides.ToDo.entity;

import java.util.Date;

import jakarta.persistence.*;

@Entity
@Table(name = "tasks")
public class Task {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "title", nullable = false)
	private String Title;
	
	
	@Column(name = "Decription")
	private String description;
	
	@Column(name = "dueDate")
	private String dueDate;
	
	@Column(name = "tastStatus")
	private String tastStatus;
	
	
	public Task() {
		
	}
	
	
	public Task(String title, String description, String dueDate, String tastStatus) {
		super();
		Title = title;
		this.description = description;
		this.dueDate = dueDate;
		this.tastStatus = tastStatus;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getTitle() {
		return Title;
	}


	public void setTitle(String title) {
		Title = title;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getDueDate() {
		return dueDate;
	}


	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}


	public String getTastStatus() {
		return tastStatus;
	}


	public void setTastStatus(String tastStatus) {
		this.tastStatus = tastStatus;
	}


	
}
