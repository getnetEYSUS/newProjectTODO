package net.javaguides.ToDo.service;

import java.util.List;

import net.javaguides.ToDo.entity.Task;

public interface TaskService {
	List<Task> getAllTasks();
	List<Task> findByDueDate(String dueDate);
	
	//List<Task> findByTitle(String title);
	
	
	Task saveTask(Task task);
	
	Task getTaskById(Long id);
	
	Task updateTask(Task task);
	
	//Task updateById(Task task, Long id);
	
	void deleteTaskById(Long id);
	
}
