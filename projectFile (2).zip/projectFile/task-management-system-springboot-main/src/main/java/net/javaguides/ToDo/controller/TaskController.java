package net.javaguides.ToDo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import net.javaguides.ToDo.entity.Task;
import net.javaguides.ToDo.service.TaskService;


@Controller
public class TaskController {
	
	private TaskService taskService;

	public TaskController(TaskService taskService) {
		super();
		this.taskService = taskService;
	}
	
	// handler method to handle list tasks and return mode and view
	@GetMapping("/tasks")
	public String listTasks(Model model) {
		model.addAttribute("tasks", taskService.getAllTasks());
		return "tasks";
	}
	
	@GetMapping("/tasks/new")
	public String createTaskForm(Model model) {
		
		// create task object to hold task form data
		Task task = new Task();
		model.addAttribute("task", task);
		return "create_task";
		
	}
	
	@GetMapping("/tasks/comlete/{id}")
	public String updateStatusForm(@PathVariable Long id,Model model) {		
		model.addAttribute("task", taskService.getTaskById(id));
		Task existingTask = taskService.getTaskById(id);
		
		existingTask.setTastStatus("completed");
		
		taskService.updateTask(existingTask);
		return "redirect:/tasks";		
	}
	
	@PostMapping("/tasks")
	public String saveTask(@ModelAttribute("task") Task task) {
		taskService.saveTask(task);
		return "redirect:/tasks";
	}
	@GetMapping("/tasks/detail/{id}")
	public String detailTaskForm(@PathVariable Long id, Model model) {
		model.addAttribute("task", taskService.getTaskById(id));
		return "detail_task";
	}
	
	
	
	@GetMapping("/tasks/edit/{id}")
	public String editTaskForm(@PathVariable Long id, Model model) {
		model.addAttribute("task", taskService.getTaskById(id));
		return "edit_task";
	}
	@PostMapping("/tasks/{id}")
	public String updateTask(@PathVariable Long id,
			@ModelAttribute("task") Task task,
			Model model) {
		
		// get task from database by id
		Task existingTask = taskService.getTaskById(id);
		existingTask.setId(id);
		existingTask.setTitle(task.getTitle());
		existingTask.setDescription(task.getDescription());
		existingTask.setDueDate(task.getDueDate());
		existingTask.setTastStatus(task.getTastStatus());
		
		taskService.updateTask(existingTask);
		return "redirect:/tasks";		
	}
	
	
	@GetMapping("/tasks/search")
	public String searchTask(@RequestParam String id,Model model) {
		
		model.addAttribute("tasks", taskService.findByDueDate(id));
		return "tasks";		
	}
	/*@GetMapping("/tasks/searchTitle")
	public String searchTaskByTitle(@RequestParam String id,Model model) {
		
		model.addAttribute("tasks", taskService.findByTitle(id));
		return "tasks";		
	}*/
	
	
	@GetMapping("/tasks/{id}")
	public String deleteTask(@PathVariable Long id) {
		taskService.deleteTaskById(id);
		return "redirect:/tasks";
	}
	
}
